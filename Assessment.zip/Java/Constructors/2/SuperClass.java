public class SuperClass {

    public SuperClass() {
        System.out.println("Superclass default constructor.");
    }

    public SuperClass(int a) {
        System.out.println("Superclass one-argument constructor with value: " + a);
    }
}
