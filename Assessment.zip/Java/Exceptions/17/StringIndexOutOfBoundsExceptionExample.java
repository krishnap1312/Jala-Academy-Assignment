public class StringIndexOutOfBoundsExceptionExample {
    public static void main(String[] args) {
        String str = "Hello";
        char ch = str.charAt(10);
    }
}
