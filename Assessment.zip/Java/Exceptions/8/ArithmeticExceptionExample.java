public class ArithmeticExceptionExample {
    public static void main(String[] args) {
        int result = 10 / 0;
        System.out.println("Result: " + result);
    }
}
