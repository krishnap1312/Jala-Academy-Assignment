public class ParentConstructor {
    ParentConstructor() {
        System.out.println("Parent Constructor");
    }
}
