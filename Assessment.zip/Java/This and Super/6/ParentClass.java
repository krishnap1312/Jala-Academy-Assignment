public class ParentClass {
    void display() {
        System.out.println("Display method in parent class.");
    }
}
