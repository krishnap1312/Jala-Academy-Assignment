public class ParentClass {
    int parentVariable = 20;

    void printParentVariable() {
        System.out.println("Parent variable: " + parentVariable);
    }
}
