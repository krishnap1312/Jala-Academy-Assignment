public class StringTrim {
    public static void main(String[] args) {
        String str = "   Hello, World!   ";
        String trimmed = str.trim();
        System.out.println("Trimmed string: '" + trimmed + "'");
    }
}
