public class NumberToString {
    public static void main(String[] args) {
        int num = 123;
        String str = String.valueOf(num);
        System.out.println("Number as String: " + str);
    }
}
