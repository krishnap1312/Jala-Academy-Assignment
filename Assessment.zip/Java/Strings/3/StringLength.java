public class StringLength {
    public static void main(String[] args) {
        String str = "Hello, World!";
        int length = str.length();
        System.out.println("Length of the string: " + length);
    }
}
