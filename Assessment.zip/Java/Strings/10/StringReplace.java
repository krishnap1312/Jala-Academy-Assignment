public class StringReplace {
    public static void main(String[] args) {
        String str = "Hello, World!";
        String replaced = str.replace('o', '0');
        System.out.println("Replaced string: " + replaced);
    }
}
