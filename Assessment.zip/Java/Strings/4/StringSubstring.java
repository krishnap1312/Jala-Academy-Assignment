public class StringSubstring {
    public static void main(String[] args) {
        String str = "Hello, World!";
        String substr = str.substring(7, 12);
        System.out.println(substr);
    }
}
