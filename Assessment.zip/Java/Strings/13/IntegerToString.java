public class IntegerToString {
    public static void main(String[] args) {
        Integer num = 456;
        String str = num.toString();
        System.out.println("Integer as String: " + str);
    }
}
