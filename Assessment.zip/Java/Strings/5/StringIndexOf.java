public class StringIndexOf {
    public static void main(String[] args) {
        String str = "Hello, World!";
        int index = str.indexOf("World");
        System.out.println("Index of 'World': " + index);
    }
}
