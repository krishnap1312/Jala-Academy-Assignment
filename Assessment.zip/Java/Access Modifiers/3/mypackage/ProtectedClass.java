package mypackage;

public class ProtectedClass {
    protected String protectedField = "Protected Field";

    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }
}
