
public class B extends A {
    public void attemptAccess() {

    }
}
