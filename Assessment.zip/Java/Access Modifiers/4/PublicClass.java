
public class PublicClass {

    public String publicField = "Public Field";

    public void publicMethod() {
        System.out.println("This is a public method.");
    }
}
