
class DefaultClass {

    String defaultField = "Default Field";

    void defaultMethod() {
        System.out.println("This is a default method.");
    }
}
