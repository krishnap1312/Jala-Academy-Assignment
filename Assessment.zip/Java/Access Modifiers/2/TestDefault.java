
public class TestDefault {
    public static void main(String[] args) {
        DefaultClass obj = new DefaultClass();

        System.out.println("Default Field: " + obj.defaultField);
        obj.defaultMethod();
    }
}
