
public class PrintName {

    
    public void printMyName() {
        String name = "Krishna";
        System.out.println("My name is: " + name);
    }

    
    public static void main(String[] args) {
        
        PrintName printer = new PrintName();
        
        
        printer.printMyName();
    }
}
