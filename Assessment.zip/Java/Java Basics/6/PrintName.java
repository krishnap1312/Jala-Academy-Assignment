public class PrintName {

    // Method to print your name
    public static void printName() {
        System.out.println("Krishna");
    }

    // Main method
    public static void main(String[] args) {
        // Calling the printName method
        printName();
    }
}
