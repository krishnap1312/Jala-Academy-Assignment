public class DataTypesExample {

    public static void main(String[] args) {
        int myInt = 42;

        boolean myBoolean = true;

        char myChar = 'A';

        float myFloat = 3.14f;

        double myDouble = 3.14159;

        System.out.println("Integer value: " + myInt);
        System.out.println("Boolean value: " + myBoolean);
        System.out.println("Character value: " + myChar);
        System.out.println("Float value: " + myFloat);
        System.out.println("Double value: " + myDouble);
    }
}
