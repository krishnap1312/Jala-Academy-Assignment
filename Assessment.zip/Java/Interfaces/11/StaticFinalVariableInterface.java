public interface StaticFinalVariableInterface {
    int CONSTANT_VALUE = 42;

    void interfaceMethod();
}
