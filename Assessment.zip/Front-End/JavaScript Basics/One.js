// Q: Write a program which consist of single line and multiline comments.


// it is a single line comment


// it is a function to print your name
function printName (name){
    console.log(`Hii my name is ${name}`);
}

printName("Krishna")

// it is multiple Line comment 
// above function prints name successfully