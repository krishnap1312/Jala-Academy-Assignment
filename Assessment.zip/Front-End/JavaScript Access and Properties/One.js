function makeDisappear(element) {
    element.style.display = 'none';
}